﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.Constantes
{
    public static class Constantes
    {
       public static string PartidaVacante { get; set;}  
    }
}
