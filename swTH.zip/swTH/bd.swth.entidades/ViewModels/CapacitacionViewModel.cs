﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.ViewModels
{
   public class CapacitacionViewModel
    {
        public int IdCapacitacion { get; set; }
        public string Nombre { get; set; }
        public int IdIndiceOcupacional { get; set; }
    }
}
