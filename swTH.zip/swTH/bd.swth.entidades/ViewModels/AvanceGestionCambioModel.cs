﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.ViewModels
{
    public partial class AvanceGestionCambioModel
    {
        public decimal Suma { get; set; }
    }
}
