﻿
using bd.swth.entidades.Negocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.ViewModels
{
    public class ViewModelDeclaracionPatrimonioPersonal
    {
        public DeclaracionPatrimonioPersonal DeclaracionPatrimonioPersonal { get; set; }
        public OtroIngreso OtroIngreso { get; set; }
    }
}
