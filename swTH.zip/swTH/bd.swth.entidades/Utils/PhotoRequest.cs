﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.Utils
{
    public class PhotoRequest
    {
        public int Id { get; set; }

        public byte[] Array { get; set; }
    }
}
