﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.ObjectTransfer
{
  public  class CapacitacioPlanificacionParametros
    {
        public int IdCapacitacionTemario { get; set; }
        public DateTime Fecha { get; set; }
    }
}
