﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swth.entidades.Enumeradores
{
    public enum Aplicacion
    {
        SwTH
    } 
}
